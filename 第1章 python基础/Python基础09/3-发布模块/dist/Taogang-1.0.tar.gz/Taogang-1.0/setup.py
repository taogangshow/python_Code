from distutils.core import setup

setup(name="Taogang", version="1.0", description="Taogang's module", author="Taogang", py_modules=['TestMsg.sendmsg','TestMsg.recvmsg'])
